/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./lib/theme.js":
/*!**********************!*\
  !*** ./lib/theme.js ***!
  \**********************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @chakra-ui/react */ \"@chakra-ui/react\");\n/* harmony import */ var _fontsource_quicksand_600_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fontsource/quicksand/600.css */ \"./node_modules/@fontsource/quicksand/600.css\");\n/* harmony import */ var _fontsource_quicksand_600_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fontsource_quicksand_600_css__WEBPACK_IMPORTED_MODULE_1__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_0__]);\n_chakra_ui_react__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\nconst breakpoints = {\n    \"1100px\": \"1100px\",\n    \"426px\": \"426px\"\n};\nconst styles = {\n    global: ()=>({\n            body: {\n                bg: \"#141822\"\n            }\n        })\n};\nconst fonts = {\n    body: `'Quicksand', sans-serif`\n};\nconst config = {\n    initialColorMode: \"dark\",\n    useSystemColorMode: false\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_0__.extendTheme)({\n    fonts,\n    config,\n    styles,\n    breakpoints\n}));\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9saWIvdGhlbWUuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUE4QztBQUNSO0FBRXRDLE1BQU1DLGNBQWM7SUFDbEIsVUFBVTtJQUNWLFNBQVM7QUFDWDtBQUVBLE1BQU1DLFNBQVM7SUFDYkMsUUFBUSxJQUFPO1lBQ2JDLE1BQU07Z0JBQ0pDLElBQUk7WUFDTjtRQUNGO0FBQ0Y7QUFFQSxNQUFNQyxRQUFRO0lBQ1pGLE1BQU0sQ0FBQyx1QkFBdUIsQ0FBQztBQUNqQztBQUVBLE1BQU1HLFNBQVM7SUFDYkMsa0JBQWtCO0lBQ2xCQyxvQkFBb0IsS0FBSztBQUMzQjtBQUVBLGlFQUFlVCw2REFBV0EsQ0FBQztJQUFFTTtJQUFPQztJQUFRTDtJQUFRRDtBQUFZLEVBQUUiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9waWNrZW1zLy4vbGliL3RoZW1lLmpzPzMzMzAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZXh0ZW5kVGhlbWUgfSBmcm9tICdAY2hha3JhLXVpL3JlYWN0J1xuaW1wb3J0ICdAZm9udHNvdXJjZS9xdWlja3NhbmQvNjAwLmNzcydcblxuY29uc3QgYnJlYWtwb2ludHMgPSB7XG4gICcxMTAwcHgnOiAnMTEwMHB4JyxcbiAgJzQyNnB4JzogJzQyNnB4J1xufVxuXG5jb25zdCBzdHlsZXMgPSB7XG4gIGdsb2JhbDogKCkgPT4gKHtcbiAgICBib2R5OiB7XG4gICAgICBiZzogJyMxNDE4MjInXG4gICAgfVxuICB9KVxufVxuXG5jb25zdCBmb250cyA9IHtcbiAgYm9keTogYCdRdWlja3NhbmQnLCBzYW5zLXNlcmlmYFxufVxuXG5jb25zdCBjb25maWcgPSB7XG4gIGluaXRpYWxDb2xvck1vZGU6ICdkYXJrJyxcbiAgdXNlU3lzdGVtQ29sb3JNb2RlOiBmYWxzZVxufVxuXG5leHBvcnQgZGVmYXVsdCBleHRlbmRUaGVtZSh7IGZvbnRzLCBjb25maWcsIHN0eWxlcywgYnJlYWtwb2ludHMgfSlcbiJdLCJuYW1lcyI6WyJleHRlbmRUaGVtZSIsImJyZWFrcG9pbnRzIiwic3R5bGVzIiwiZ2xvYmFsIiwiYm9keSIsImJnIiwiZm9udHMiLCJjb25maWciLCJpbml0aWFsQ29sb3JNb2RlIiwidXNlU3lzdGVtQ29sb3JNb2RlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./lib/theme.js\n");

/***/ }),

/***/ "./pages/_app.jsx":
/*!************************!*\
  !*** ./pages/_app.jsx ***!
  \************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @chakra-ui/react */ \"@chakra-ui/react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _lib_theme__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../lib/theme */ \"./lib/theme.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__, _lib_theme__WEBPACK_IMPORTED_MODULE_4__]);\n([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__, _lib_theme__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\nconst Hydrated = ({ children  })=>{\n    const [hydration, setHydration] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);\n    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{\n        if (false) {}\n    }, []);\n    return hydration ? children : null;\n};\nfunction App({ Component , pageProps  }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Hydrated, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.ChakraProvider, {\n            theme: _lib_theme__WEBPACK_IMPORTED_MODULE_4__[\"default\"],\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\User\\\\Documents\\\\community-ranking\\\\pages\\\\_app.jsx\",\n                lineNumber: 22,\n                columnNumber: 9\n            }, this)\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\User\\\\Documents\\\\community-ranking\\\\pages\\\\_app.jsx\",\n            lineNumber: 21,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\User\\\\Documents\\\\community-ranking\\\\pages\\\\_app.jsx\",\n        lineNumber: 20,\n        columnNumber: 5\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQThCO0FBQ21CO0FBQ047QUFDWDtBQUVoQyxNQUFNSSxXQUFXLENBQUMsRUFBRUMsU0FBUSxFQUFFLEdBQUs7SUFDakMsTUFBTSxDQUFDQyxXQUFXQyxhQUFhLEdBQUdMLCtDQUFRQSxDQUFDLEtBQUs7SUFFaERELGdEQUFTQSxDQUFDLElBQU07UUFDZCxJQUFJLEtBQWtCLEVBQWEsRUFFbEM7SUFDSCxHQUFHLEVBQUU7SUFFTCxPQUFPSyxZQUFZRCxXQUFXLElBQUk7QUFDcEM7QUFFZSxTQUFTRyxJQUFJLEVBQUVDLFVBQVMsRUFBRUMsVUFBUyxFQUFFLEVBQUU7SUFDcEQscUJBQ0UsOERBQUNOO2tCQUNDLDRFQUFDSiw0REFBY0E7WUFBQ0csT0FBT0Esa0RBQUtBO3NCQUMxQiw0RUFBQ007Z0JBQVcsR0FBR0MsU0FBUzs7Ozs7Ozs7Ozs7Ozs7OztBQUloQyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcGlja2Vtcy8uL3BhZ2VzL19hcHAuanN4PzRjYjMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICcuLi9zdHlsZXMvZ2xvYmFscy5jc3MnXG5pbXBvcnQgeyBDaGFrcmFQcm92aWRlciB9IGZyb20gJ0BjaGFrcmEtdWkvcmVhY3QnXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgdGhlbWUgZnJvbSAnLi4vbGliL3RoZW1lJ1xuXG5jb25zdCBIeWRyYXRlZCA9ICh7IGNoaWxkcmVuIH0pID0+IHtcbiAgY29uc3QgW2h5ZHJhdGlvbiwgc2V0SHlkcmF0aW9uXSA9IHVzZVN0YXRlKGZhbHNlKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICBzZXRIeWRyYXRpb24odHJ1ZSlcbiAgICB9XG4gIH0sIFtdKVxuXG4gIHJldHVybiBoeWRyYXRpb24gPyBjaGlsZHJlbiA6IG51bGxcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xuICByZXR1cm4gKFxuICAgIDxIeWRyYXRlZD5cbiAgICAgIDxDaGFrcmFQcm92aWRlciB0aGVtZT17dGhlbWV9PlxuICAgICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XG4gICAgICA8L0NoYWtyYVByb3ZpZGVyPlxuICAgIDwvSHlkcmF0ZWQ+XG4gIClcbn1cbiJdLCJuYW1lcyI6WyJDaGFrcmFQcm92aWRlciIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidGhlbWUiLCJIeWRyYXRlZCIsImNoaWxkcmVuIiwiaHlkcmF0aW9uIiwic2V0SHlkcmF0aW9uIiwiQXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.jsx\n");

/***/ }),

/***/ "./node_modules/@fontsource/quicksand/600.css":
/*!****************************************************!*\
  !*** ./node_modules/@fontsource/quicksand/600.css ***!
  \****************************************************/
/***/ (() => {



/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "@chakra-ui/react":
/*!***********************************!*\
  !*** external "@chakra-ui/react" ***!
  \***********************************/
/***/ ((module) => {

"use strict";
module.exports = import("@chakra-ui/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.jsx"));
module.exports = __webpack_exports__;

})();